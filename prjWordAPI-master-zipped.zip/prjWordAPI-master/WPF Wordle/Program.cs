﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPF_Wordle
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, try to geuss a five letter word, failure.");

            Game WPF_Wordle = new Game();
            WPF_Wordle.WPF_Wordle();
        }

        class Game
        {
            public void WPF_Wordle()
            {
                string wordToGeuss = "super";
                string input = null;

                input = Console.ReadLine();

                if (input.Length == 5)
                {
                    //Continue executing
                    if (input == wordToGeuss)
                    {
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.WriteLine(wordToGeuss);
                        Console.ResetColor();
                        Console.WriteLine("Congratulations failure, you geussed the word: " + wordToGeuss + ".");
                    }
                    else
                    {
                        for (int i = 0; i < wordToGeuss.Length; i++)
                        {
                            if (wordToGeuss[i] == input[i])
                            {

                                Console.BackgroundColor = ConsoleColor.Green;
                                Console.Write(input[i]);
                            }
                            else
                            {
                                if (wordToGeuss.Contains(input[i]))
                                {
                                    Console.BackgroundColor = ConsoleColor.Yellow;
                                    Console.Write(input[i]);
                                }
                                else
                                {
                                    Console.BackgroundColor = ConsoleColor.Red;
                                    Console.Write(input[i]);
                                }
                            }

                            if (i == wordToGeuss.Length - 1)
                            {
                                Console.WriteLine("");
                            }
                        }

                        Console.ResetColor();
                        WPF_Wordle();
                    }
                }
                else
                {
                    Console.WriteLine("Oops, the word you entred is either too short or too long.");
                    WPF_Wordle();
                }
            }
        }
    }
}
