﻿using System.Text.Json;

namespace prjWordAPI
{
    public class newdbControl
    {
    }
}
