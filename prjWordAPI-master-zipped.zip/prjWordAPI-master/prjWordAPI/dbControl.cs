﻿using System.Net;
using System;
using Microsoft.AspNetCore.Identity;
using System.Web;
using System;
using System.Data.SqlClient;
using System.Data.Common;
//
using System.Text.Json;
using System.Text.Json.Serialization;
//using System.Web;

namespace prjWordAPI
{
    //connect to https://wordapidata.000webhostapp.com/
    public class dbControl
    {
        //Method used to connect
        private string url = "https://wordapidata.000webhostapp.com/?getuserdb";
        private List<String> req = new List<string>();
        private List <String> afri= new List <String>();
        private List<String> engL = new List<String>();
        private List<String> xhosa = new List<String>();
        public static string connectionString = "Data Source=lab000000//SQLEXPRESS;Initial Catalog=prjWordAPI;Integrated Security=True";
        public void connectDB()
        {
            req.Add("getnamesenglish");   //0
            req.Add("getnamesafrikaans"); //1
            req.Add("getnamesxhosa");    //2
            req.Add("getuserdb");         //3
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url + req[3]);
            request.Method = "GET";
            request.Timeout = Timeout.Infinite;
            request.KeepAlive = true;

            long length = 0;
            try
            {

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    length = response.ContentLength;
                    Stream dataStream = response.GetResponseStream();
                    StreamReader reader = new StreamReader(dataStream);
                    string responseFromServer = reader.ReadToEnd();
                    Console.WriteLine(responseFromServer);
                    string[] stuff = responseFromServer.Split(new char[] {'{'});
                    int c = 0;
                    while (c < stuff.Length) //{ if (stuff[c].Equals(',')) { stuff[c].Remove(','); else { c++; } }
                    {
                        String[] temp = stuff[c].Split(new char[]{'}'});
                        int e = 0;
                        while (c < temp.Length)
                        {
                            UserLoginInfo.add(c + "-" + temp[e].Trim());
                            c++;
                        }
                    } 
                    int i = 0;
                    while (i < stuff.Length)
                    {
                        Console.WriteLine(stuff[i]+"\n");
                            i++;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
            }
        }
        //A method used to send URL data to the database (getuserdb)
        public void InsertDataFromUrl(string connectionString, string url)
        {
            // Parse the URL to extract the data
            var query = HttpUtility.ParseQueryString(new Uri(url).Query);
            var Name = query["Name"];
            var Password = query["Password"];
            var Image = query["age"];

            // Insert the data into the SQL database
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO userdb (Name, Password, Image) VALUES (@Name, @Password, @Image)", connection);
                command.Parameters.AddWithValue("@Name", Name);
                command.Parameters.AddWithValue("@Password", Password);
                command.Parameters.AddWithValue("@Image", Image);

                command.ExecuteNonQuery();
            }
        }
        //A method used to send URL data to the database (getnamesenglish)
        public void InsertDataFromUrl2(string connectionString, string url)
        {
            // Parse the URL to extract the data
            var query = HttpUtility.ParseQueryString(new Uri(url).Query);
            var Name = query["Name"];

            // Insert the data into the SQL database
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO namesenglish (Name) VALUES (@Name)", connection);
                command.Parameters.AddWithValue("@Name", Name);

                command.ExecuteNonQuery();
            }
        }
        //A method used to send URL data to the database (getnamesafrikaans)
        public void InsertDataFromUrl3(string connectionString, string url)
        {
            // Parse the URL to extract the data
            var query = HttpUtility.ParseQueryString(new Uri(url).Query);
            var Name = query["Name"];

            // Insert the data into the SQL database
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO namesafrikaans (Name) VALUES (@Name)", connection);
                command.Parameters.AddWithValue("@Name", Name);

                command.ExecuteNonQuery();
            }
        }
        //A method used to send URL data to the database (getnamesxhosa)
        public void InsertDataFromUrl4(string connectionString, string url)
        {
            // Parse the URL to extract the data
            var query = HttpUtility.ParseQueryString(new Uri(url).Query);
            var Name = query["Name"];

            // Insert the data into the SQL database
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var command = new SqlCommand("INSERT INTO namesxhosa (Name) VALUES (@Name)", connection);
                command.Parameters.AddWithValue("@Name", Name);

                command.ExecuteNonQuery();
            }
        }
    }
}
